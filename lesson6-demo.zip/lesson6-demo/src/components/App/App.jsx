// import CardsList from '../CardsList/CardList'
import { useState } from 'react'
import './App.css'

function App() {
  const defaultTeams = [
    {
      id: 1,
      name: 'Dragons United',
      members: ['David Miller', 'Ethan Turner', 'Natalie Clark', 'Sophie Gomez', 'Tom Hanks']
    },
    {
      id: 2,
      name: 'Golden Eagles',
      members: ['Lisa Ray', 'Harry Ford', 'Betty Cooper', 'George King', 'Alice Morgan']
    },
    {
      id: 3,
      name: 'Mighty Warriors',
      members: ['Sam Wilson', 'John Norton', 'Emma Cartright', 'Daniel Lewis', 'Megan Stone']
    },
    {
      id: 4,
      name: 'Falcon Flyer',
      members: ['Oscar Wilde', 'Robert Brown', 'Victoria Smith', 'Rachel Adams', 'Matthew Johns']
    },
    {
      id: 5,
      name: 'Storm Breakers',
      members: ['Lucas White', 'Eva Taylor', 'Charles Anderson', 'Emily Johnson', 'Aaron Carter']
    }
  ];

  const newTeam = {
    id: Date.now(),
    name: 'New Team',
    members: ['John Doe', 'Jane Smith'],
  }

  const [teams, setTeams] = useState(defaultTeams);

  const addTeam = () => {
    setTeams(prevTeams => [...prevTeams, newTeam])
  }

  const removeTeam = (teamId) => {
    setTeams(prevTeams => prevTeams.filter(team => team.id !== teamId))
  }

  [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].filter((item) => item % 2 == 0) // новый массив [2, 4, 6, 8, 10]


  // const badIncrement = () => {
  //   // запоминает counter
  //   setCounter(counter + 1) // Использует текущее значение напрямую
  //   // все создастся заново внутри app
  //   setCounter(counter + 1) // Все еще использует то же самое значение
  // }

  // const goodIncrement = () => {
  //   setCounter((prevCounter) => prevCounter + 1); // Использует предыдущее состояние
  //   setCounter((prevCounter) => prevCounter + 1); // Использует обновленнное состояние
  // }

  // // Vue (реактивно)
  // let c = 0;
  // const inc = () => c++;

  return (
    <div className='App'>
      <button onClick={addTeam}>Добавить команду</button>
      <div className="teams-list">
        {teams.map(team => (
          <div key={team.id} className="team-card">
            <h3>{team.name}</h3>
            <button onClick={() => removeTeam(team.id)}>Удалить</button>
            <ul>
              {team.members.map((member, index) => (
                <li key={index}>{member}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  )
}

export default App
