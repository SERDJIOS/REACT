import styles from'./TeamCard.module.css';

export default function TeamCard({ name, members }) {
  return (
    <div className={styles.teamCard}>
      <h3 className={styles.name}>{name}</h3>

      <ul className={styles.list}>
        {members.map(member => (
          <li key={member}>{member}</li>
        ))}
      </ul>
    </div>
  )
}


